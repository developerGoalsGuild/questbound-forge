# authorizer.py
from __future__ import annotations
import os, json, logging
from typing import Any, Dict

import jwt  # for safe header peek (no decoding)

# Local JWT
from security import verify_local_jwt  # noqa
# Cognito JWT
from cognito import verify_cognito_jwt  # noqa


class Unauthorized(Exception):
    pass


# --- Logging config (toggleable) ---
def _to_bool(v: str | None, default=False) -> bool:
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")

AUTH_LOG_ENABLED = _to_bool(os.getenv("AUTH_LOG_ENABLED"), False)
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()

logger = logging.getLogger("authorizer")
# Avoid duplicate handlers if Lambda reuses the runtime
if not logger.handlers:
    handler = logging.StreamHandler()
    # Basic single-line log; message body is JSON for easy CloudWatch insights
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(handler)
logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))


def _peek_jwt_header(token: str) -> Dict[str, Any]:
    try:
        h = jwt.get_unverified_header(token)
        return {"kid": h.get("kid"), "alg": h.get("alg")}
    except Exception:
        return {}

def _dbg(event_name: str, **fields: Any) -> None:
    if not AUTH_LOG_ENABLED:
        return
    # sanitize possibly sensitive inputs
    tok = fields.pop("token", None)
    if tok:
        hdr = _peek_jwt_header(tok)
        fields["token_hint"] = {"len": len(tok), **({"kid": hdr.get("kid")} if hdr.get("kid") else {}), **({"alg": hdr.get("alg")} if hdr.get("alg") else {})}
    try:
        logger.info(json.dumps({"event": event_name, **fields}, default=str))
    except Exception:
        # Never let logging break auth flow
        logger.warning("failed to serialize debug log for event=%s", event_name)


def _extract_token(event: dict) -> str:
    # REST TOKEN authorizer
    if "authorizationToken" in event:
        raw = event["authorizationToken"]
        parts = raw.split()
        token = parts[-1] if parts else raw
        _dbg("token_extracted", source="TOKEN", token=token)
        return token
    # REQUEST/HTTP API
    headers = event.get("headers") or {}
    for k in ("authorization", "Authorization"):
        if k in headers and headers[k]:
            raw = headers[k]
            parts = raw.split()
            token = parts[-1] if parts else raw
            _dbg("token_extracted", source="HEADER", header_key=k, token=token)
            return token
    _dbg("token_missing")
    raise Unauthorized("No token provided")


def _allow_policy(principal: str, resource: str, context: Dict[str, Any]) -> dict:
    return {
        "principalId": principal,
        "policyDocument": {
            "Version": "2012-10-17",
            "Statement": [{"Action": "execute-api:Invoke", "Effect": "Allow", "Resource": resource}],
        },
        "context": context,
    }


def _httpapi_simple_response(authorized: bool, context: Dict[str, Any]) -> dict:
    return {"isAuthorized": authorized, "context": context}


def handler(event, context):
    req_meta = {
        "version": event.get("version"),
        "routeKey": event.get("routeKey"),
        "methodArn": event.get("methodArn"),
        "aws_request_id": getattr(context, "aws_request_id", None),
        "stage": (event.get("requestContext") or {}).get("stage"),
    }
    _dbg("auth_start", **req_meta)

    try:
        token = _extract_token(event)
        claims = None
        provider = None

        # Try local JWT first
        try:
            claims = verify_local_jwt(token)
            provider = "local"
            _dbg("local_verify_ok", sub=claims.get("sub"), scope=claims.get("scope"))
        except Exception as e_local:
            _dbg(
                "local_verify_failed",
                error_type=type(e_local).__name__,
                error=str(e_local),
            )
            # Fallback to Cognito
            try:
                claims = verify_cognito_jwt(token)
                provider = "cognito"
                _dbg(
                    "cognito_verify_ok",
                    sub=claims.get("sub"),
                    token_use=claims.get("token_use"),
                    scope=claims.get("scope"),
                )
            except Exception as e_cog:
                _dbg(
                    "cognito_verify_failed",
                    error_type=type(e_cog).__name__,
                    error=str(e_cog),
                )
                # For HTTP API Lambda authorizers, return structured deny
                if event.get("version") == "2.0" and "routeKey" in event:
                    _dbg("auth_deny_httpapi", reason="verify_failed", **req_meta)
                    return _httpapi_simple_response(False, {"error": "Unauthorized"})
                # For REST/API Gateway TOKEN/REQUEST, raising triggers 401/403
                raise Unauthorized("Unauthorized")

        principal = claims.get("sub", "user")
        ctx = {
            "provider": provider,
            "sub": claims.get("sub", ""),
            "email": claims.get("email", ""),
            "scope": claims.get("scope", ""),
        }

        # HTTP API simple response
        if event.get("version") == "2.0" and "routeKey" in event:
            _dbg("auth_allow_httpapi", principal=principal, **req_meta)
            return _httpapi_simple_response(True, ctx)

        # REST policy response
        method_arn = event.get("methodArn", "*")
        _dbg("auth_allow_rest", principal=principal, methodArn=method_arn, **req_meta)
        return _allow_policy(principal, method_arn, ctx)

    except Exception as e:
        _dbg("auth_exception", error_type=type(e).__name__, error=str(e), **req_meta)
        # HTTP API simple deny
        if event.get("version") == "2.0" and "routeKey" in event:
            return _httpapi_simple_response(False, {"error": "Unauthorized"})
        # REST/API Gateway: raising signals failure to API Gateway
        raise Unauthorized("Unauthorized")
