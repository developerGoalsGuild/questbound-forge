# Database operations for guild service

