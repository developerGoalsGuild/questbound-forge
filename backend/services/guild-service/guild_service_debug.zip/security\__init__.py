# Security module for guild service

